from plyer import notification
from bs4 import BeautifulSoup
import requests
from PIL import Image
import json
import geocoder
from urllib.request import urlopen

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"}

html = "html.parser"
mandaw_png = "Mandaw Logo.png"
mandaw_ico = "Mandaw Logo.ico" 

res = requests.get("https://ipinfo.io/")
data = res.json()

city = data["city"]
print("\n" + city + "\n")

city = city + " weather" 

def weather(city):
    res = requests.get(f"https://www.google.com/search?q={city}&oq={city}&aqs=chrome.0.35i39l2j0l4j46j69i60.6128j1j7&sourceid=chrome&ie=UTF-8",headers=headers)
    print("Searching in google......\n")
    soup = BeautifulSoup(res.text, html)   
    location = soup.select("#wob_loc")[0].getText().strip()     
    info = soup.select("#wob_dc")[0].getText().strip() 
    degrees = soup.select("#wob_tm")[0].getText().strip()
    city = city.replace(" weather", ",")

    filename = "weather.png"
    img = Image.open(filename)
    img.save("weather.ico")

    notification.notify(title="Weather in " + city, message="\n" + degrees + "°C  " + " " + location + ",  " + info, app_icon="weather.ico",timeout=1)

    time(city)

def time(city):
    city = city + " weather"
    res = requests.get(f"https://www.google.com/search?q={city}&oq={city}&aqs=chrome.0.35i39l2j0l4j46j69i60.6128j1j7&sourceid=chrome&ie=UTF-8",headers=headers)
    print("Searching for the time......\n")
    soup = BeautifulSoup(res.text, html)
    time = soup.select("#wob_dts")[0].getText().strip() 
    city = city.replace(" weather", " ") 

    filename = "worldclock.png"
    img = Image.open(filename)
    img.save("worldclock.ico")

    notification.notify(title="Time in " + city, message="\n" + time, app_icon="worldclock.ico",timeout=1)

    joke()

def joke():
    filename = mandaw_png
    img = Image.open(filename)
    img.save(mandaw_ico)
    print("Searching for joke of the day......\n")

    notification.notify(title="Joke of the Day", message="What do you use to cut wood? whA saaawwww dude!", app_icon=mandaw_ico,timeout=30)

def idle():
    print("Booting up Mandaw......\n")

    filename = mandaw_png
    img = Image.open(filename)
    img.save(mandaw_ico)

    notification.notify(title="Hi There!", message="Good Morning", app_icon=mandaw_ico,timeout=1)

    weather(city)

idle()